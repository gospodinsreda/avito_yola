class BookingAnalyzer {
    constructor() {
        this.parser = new BookingParser();
        this.navigation = null;
        this.init();
    }
     async init() {
        try {
            // Инициализация с получением sessionId
            const sessionId = await this.parser.getSessionId();
            if (sessionId) {
                this.navigation = new BookingNavigation(sessionId);
                this.attachEventListeners();
                console.log('BookingAnalyzer initialized with session:', sessionId);
            } else {
                console.warn('Session ID not found');
            }
        } catch (error) {
            console.error('Error during initialization:', error);
        }
    }
     attachEventListeners() {
        // Слушаем сообщения от popup и background
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log('Content script received message:', request.action, request.params);
            
            // Обработка ping для проверки загрузки content script
            if (request.action === 'ping') {
                console.log('Responding to ping');
                sendResponse({ status: 'ok' });
                return true;
            }
            
            // Обрабатываем остальные сообщения
            switch (request.action) {
                case 'parseBookings':
                    console.log('Starting parseBookings with params:', request.params);
                    // Если нужна навигация на новую страницу
                    if (request.params?.dateFrom && request.params?.dateTo) {
                        const url = this.navigation.generateBookingsUrl(
                            request.params.dateFrom,
                            request.params.dateTo,
                            request.params.dateType
                        );
                        console.log('Generated URL for navigation:', url);
                        // Сначала отправляем ответ с URL для навигации
                        sendResponse({ 
                            success: true, 
                            needsNavigation: true,
                            url: url 
                        });
                    } else {
                        console.log('Parsing current page...');
                        // Если навигация не нужна, парсим текущую страницу
                        this.handleParseBookings(request.params).then(response => {
                            console.log('Parse completed, sending response:', response);
                            sendResponse(response);
                        }).catch(error => {
                            console.error('Error during parsing:', error);
                            sendResponse({ success: false, error: error.message });
                        });
                    }
                    return true;
                case 'parseHotelInfo':
                    console.log('Starting parseHotelInfo');
                    this.handleParseHotelInfo().then(response => {
                        console.log('Hotel info parsed, sending response:', response);
                        sendResponse(response);
                    }).catch(error => {
                        console.error('Error parsing hotel info:', error);
                        sendResponse({ success: false, error: error.message });
                    });
                    return true;
            }
        });
    }
     // Обработка парсинга бронирований
    async handleParseBookings(params) {
        try {
            console.log('handleParseBookings started');
            // Устанавливаем максимальное количество результатов на странице
            if (this.navigation) {
                console.log('Setting results per page to 100');
                await this.navigation.setResultsPerPage(100);
                // Ждем обновления после изменения количества результатов
                await new Promise(resolve => setTimeout(resolve, 2000));
            }

            // Парсим бронирования
            console.log('Starting to parse bookings');
            const bookings = await this.parser.parseBookings();
            console.log('Parsed bookings:', bookings);
            return {
                success: true,
                data: bookings
            };
        } catch (error) {
            console.error('Error in handleParseBookings:', error);
            throw error;
        }
    }
     // Обработка парсинга информации об отеле
    async handleParseHotelInfo() {
        try {
            console.log('handleParseHotelInfo started');
            const hotelInfo = await this.parser.parseHotelInfo();
            console.log('Parsed hotel info:', hotelInfo);
            return {
                success: true,
                data: hotelInfo
            };
        } catch (error) {
            console.error('Error in handleParseHotelInfo:', error);
            throw error;
        }
    }
}

// Инициализация
console.log('Content script loaded, initializing BookingAnalyzer');
const analyzer = new BookingAnalyzer();