const BookingHelpers = {
    // Ожидание загрузки элемента
    waitForElement: function(selector, timeout = 5000) {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            
            const checkElement = () => {
                const element = document.querySelector(selector);
                if (element) {
                    resolve(element);
                } else if (Date.now() - startTime > timeout) {
                    reject(new Error(`Timeout waiting for ${selector}`));
                } else {
                    requestAnimationFrame(checkElement);
                }
            };
            
            checkElement();
        });
    },

    // Форматирование даты
    formatDate: function(dateString) {
        return new Date(dateString).toLocaleDateString();
    },

    // Очистка текста
    cleanText: function(text) {
        return text?.trim().replace(/\s+/g, ' ') || '';
    }
}; 