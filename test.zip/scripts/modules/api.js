class BookingAPI {
    constructor() {
        this.baseUrl = 'https://your-server.com/api'; // Замените на ваш URL
        this.storage = new BookingStorage();
    }

    // Формирование заголовков
    async getHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-Session-ID': await this.storage.getData('sessionId')
        };
    }

    // Отправка данных на сервер
    async sendData(endpoint, data) {
        try {
            const response = await fetch(`${this.baseUrl}/${endpoint}`, {
                method: 'POST',
                headers: await this.getHeaders(),
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            console.log(`Data sent to ${endpoint} successfully:`, result);
            return result;
        } catch (error) {
            console.error('Error sending data:', error);
            // Сохраняем данные локально, если отправка не удалась
            await this.storage.saveData(data, `failed_${endpoint}`);
            throw error;
        }
    }

    // Отправка информации о бронированиях
    async sendBookings(bookings) {
        return this.sendData('bookings', bookings);
    }

    // Отправка информации об отеле
    async sendHotelInfo(hotelInfo) {
        return this.sendData('hotel-info', hotelInfo);
    }

    // Повторная отправка неудачных запросов
    async retrySendingFailedData() {
        const failedData = await this.storage.getAllData();
        
        for (const [key, data] of Object.entries(failedData)) {
            if (key.startsWith('failed_')) {
                const endpoint = key.replace('failed_', '');
                try {
                    await this.sendData(endpoint, data);
                    await this.storage.clearData(key);
                } catch (error) {
                    console.error(`Failed to retry sending data for ${endpoint}:`, error);
                }
            }
        }
    }
}

window.BookingAPI = BookingAPI; 