class BookingParser {
    // Парсинг ID сессии
    async getSessionId() {
        const url = window.location.href;
        const sessionMatch = url.match(/ses=([^&]+)/);
        return sessionMatch ? sessionMatch[1] : null;
    }

    // Парсинг информации о бронированиях
    async parseBookings() {
        const bookings = [];
        let hasNextPage = true;
        let currentPage = 1;

        while (hasNextPage) {
            const pageBookings = await this.parseCurrentPage();
            bookings.push(...pageBookings);
            
            hasNextPage = await this.hasNextPage();
            if (hasNextPage) {
                await this.goToNextPage();
                currentPage++;
            }
        }

        return bookings;
    }

    // Проверка наличия следующей страницы
    async hasNextPage() {
        return !document.querySelector('.bui-pagination__next-arrow').classList.contains('bui-pagination__item--disabled');
    }

    // Парсинг текущей страницы
    async parseCurrentPage() {
        const bookingRows = document.querySelectorAll('.bui-table__body .bui-table__row');
        const allBookings = Array.from(bookingRows).map(row => this.parseBookingRow(row));
        // Фильтруем только бронирования со статусом OK
        return allBookings.filter(booking => booking.status === 'OK');
    }

    // Парсинг одной строки бронирования
    parseBookingRow(row) {
        const extractText = (selector) => row.querySelector(selector)?.textContent?.trim() || '';
        const extractNumber = (text) => parseFloat(text.replace(/[^0-9.,]/g, '')) || 0;

        // Парсинг информации о гостях
        const guestsInfo = row.querySelector('th.bui-table__cell .bui-f-font-caption')?.textContent || '';
        const [adults, children] = this.parseGuestsInfo(guestsInfo);

        // Парсинг цены и валюты
        const priceText = extractText('td[data-heading="Price"] span');
        const [price, currency] = this.parsePriceAndCurrency(priceText);

        return {
            id: extractText('td[data-heading="Booking number"] a span'),
            guestName: extractText('th.bui-table__cell a span'),
            price,
            currency,
            commission: extractNumber(extractText('td[data-heading="Commission"] span')),
            checkIn: extractText('td[data-heading="Check-in"] span'),
            checkOut: extractText('td[data-heading="Check-out"] span'),
            roomType: extractText('td[data-heading="Rooms"]'),
            bookingDate: extractText('td[data-heading="Booked on"] span'),
            status: extractText('.reservation-status__main span'),
            guests: {
                adults,
                children
            }
        };
    }

    // Парсинг инфо��мации о гостях
    parseGuestsInfo(guestsInfo) {
        const adultsMatch = guestsInfo.match(/(\d+)\s*adults?/);
        const childrenMatch = guestsInfo.match(/(\d+)\s*child(?:ren)?/);
        
        return [
            adultsMatch ? parseInt(adultsMatch[1]) : 0,
            childrenMatch ? parseInt(childrenMatch[1]) : 0
        ];
    }

    // Парсинг цены и валюты
    parsePriceAndCurrency(priceText) {
        const match = priceText.match(/([€$£¥])\s*(\d+(?:[.,]\d+)?)/);
        if (!match) return [0, ''];
        
        const currencySymbols = {
            '€': 'EUR',
            '$': 'USD',
            '£': 'GBP',
            '¥': 'JPY'
        };

        return [
            parseFloat(match[2].replace(',', '.')),
            currencySymbols[match[1]] || match[1]
        ];
    }

    // Парсинг информации об отеле
    async parseHotelInfo() {
        // Получаем фотографию отеля
        const photoElement = document.querySelector('.bui-avatar img');
        const photoUrl = photoElement ? photoElement.src : '';
        const hotelName = photoElement ? photoElement.alt : '';

        return {
            name: hotelName,
            hotelId: new URLSearchParams(window.location.search).get('hotel_id'),
            photo: photoUrl,
            date: new Date().toISOString()
        };
    }
}

window.BookingParser = BookingParser; 