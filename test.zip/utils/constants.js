const BOOKING_CONSTANTS = {
    SELECTORS: {
        BOOKING_ITEM: '.booking-item',
        GUEST_NAME: '.guest-name',
        PRICE: '.price',
        CURRENCY: '.currency',
        CHECK_IN: '.check-in',
        CHECK_OUT: '.check-out',
        HOTEL_NAME: '.hotel-name',
        HOTEL_ADDRESS: '.hotel-address',
        HOTEL_IMAGE: '.hotel-image',
        NEXT_PAGE: '.next-page'
    },
    URLS: {
        BASE: 'https://admin.booking.com/hotel/hoteladmin',
        SECTIONS: {
            BOOKINGS: 'bookings',
            HOTEL_INFO: 'hotel-info',
            INBOX: 'messaging/inbox'
        }
    }
}; 