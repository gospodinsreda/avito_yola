class BookingNavigation {
    constructor(sessionId) {
        this.sessionId = sessionId;
        this.baseUrl = 'https://admin.booking.com/hotel/hoteladmin/extranet_ng/manage';
    }

    // Генерация URL для разных разделов
    generateUrl(section, params = {}) {
        const defaultParams = {
            ses: this.sessionId,
            lang: 'en'
        };

        const queryParams = new URLSearchParams({
            ...defaultParams,
            ...params
        });

        return `${this.baseUrl}/${section}?${queryParams.toString()}`;
    }

    // Генерация URL для страницы бронирований с датами
    generateBookingsUrl(dateFrom, dateTo, dateType = 'booking') {
        const params = {
            ses: this.sessionId,
            lang: 'en',
            date_from: dateFrom,
            date_to: dateTo,
            date_type: dateType,
            hotel_id: new URLSearchParams(window.location.search).get('hotel_id')
        };

        return `${this.baseUrl}/search_reservations.html?${new URLSearchParams(params).toString()}`;
    }

    // Переход на следующую страницу
    async goToNextPage() {
        const nextButton = document.querySelector('.bui-pagination__next-arrow:not(.bui-pagination__item--disabled) a');
        if (nextButton) {
            nextButton.click();
            // Ждем обновления контента
            await this.waitForContentUpdate();
            return true;
        }
        return false;
    }

    // Ожидание обновления контента после навигации
    async waitForContentUpdate() {
        return new Promise(resolve => {
            const observer = new MutationObserver((mutations, obs) => {
                const tableBody = document.querySelector('.bui-table__body');
                if (tableBody) {
                    obs.disconnect();
                    // Даем небольшую задержку для полной загрузки данных
                    setTimeout(resolve, 500);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // Таймаут на случай, если что-то пойдет не так
            setTimeout(() => {
                observer.disconnect();
                resolve();
            }, 5000);
        });
    }

    // Установка количества результатов на странице
    async setResultsPerPage(count) {
        const select = document.querySelector('#reservations_table_pagination');
        if (select && select.value !== count.toString()) {
            select.value = count.toString();
            const event = new Event('change', { bubbles: true });
            select.dispatchEvent(event);
            await this.waitForContentUpdate();
        }
    }

    // Навигация между разделами
    async navigateToSection(section, params = {}) {
        const url = this.generateUrl(section, params);
        window.location.href = url;
        await this.waitForContentUpdate();
    }

    // Навигация на страницу бронирований с определенными датами
    async navigateToBookings(dateFrom, dateTo, dateType) {
        const url = this.generateBookingsUrl(dateFrom, dateTo, dateType);
        window.location.href = url;
        await this.waitForContentUpdate();
    }
}

window.BookingNavigation = BookingNavigation; 