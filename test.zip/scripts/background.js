// Слушаем установку расширения
chrome.runtime.onInstalled.addListener(() => {
    console.log('Booking Analyzer installed');
});

// Отслеживаем завершение навигации
let isNavigatingToNewDates = false;

// Функция для запуска парсинга
function startParsing(tabId) {
    console.log('Attempting to start parsing on tab:', tabId);
    chrome.tabs.sendMessage(tabId, { 
        action: 'parseBookings',
        params: {} // Пустые параметры для парсинга текущей страницы
    }, response => {
        if (chrome.runtime.lastError) {
            console.error('Error sending parse message:', chrome.runtime.lastError);
            // Пробуем еще раз через 2 секунды
            setTimeout(() => startParsing(tabId), 2000);
        } else {
            console.log('Parse message sent successfully, response:', response);
            // Сохраняем результаты в storage
            if (response?.success && response?.data) {
                chrome.storage.local.set({ 
                    lastParseResult: response.data,
                    lastParseTime: new Date().toISOString()
                }, () => {
                    console.log('Parse results saved to storage');
                    // Отправляем сообщение всем открытым popup об обновлении данных
                    chrome.runtime.sendMessage({ 
                        action: 'parseComplete', 
                        data: response.data 
                    });
                });
            }
            isNavigatingToNewDates = false;
        }
    });
}

// Слушаем обновление вкладок
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    console.log('Tab updated:', { tabId, changeInfo, url: tab.url });
    
    // Проверяем, что страница загружена и URL соответствует admin.booking.com
    if (changeInfo.status === 'complete' && tab.url?.includes('admin.booking.com')) {
        console.log('Booking.com admin page loaded:', tab.url);
        
        // Даем время для полной загрузки страницы
        setTimeout(() => {
            // Проверяем, загружены ли content scripts
            chrome.tabs.sendMessage(tabId, { action: 'ping' }, response => {
                if (chrome.runtime.lastError) {
                    console.log('Content scripts not loaded, injecting...');
                    
                    // Если content scripts не загружены, загружаем их
                    chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        files: [
                            'scripts/modules/parser.js',
                            'scripts/modules/navigation.js',
                            'scripts/content.js'
                        ]
                    }).then(() => {
                        console.log('Content scripts injected successfully');
                        if (isNavigatingToNewDates) {
                            console.log('Navigation detected, waiting before parsing...');
                            // Увеличиваем задержку для гарантии загрузки страницы
                            setTimeout(() => startParsing(tabId), 5000);
                        }
                    }).catch(err => {
                        console.error('Failed to inject content scripts:', err);
                    });
                } else {
                    console.log('Content scripts already loaded, response:', response);
                    if (isNavigatingToNewDates) {
                        console.log('Navigation detected, waiting before parsing...');
                        // Увеличиваем задержку для гарантии загрузки страницы
                        setTimeout(() => startParsing(tabId), 5000);
                    }
                }
            });
        }, 2000);
    }
});

// Слушаем сообщения от popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message:', request);
    if (request.action === 'startNavigation') {
        console.log('Starting navigation...');
        isNavigatingToNewDates = true;
        sendResponse({ status: 'ok' });
    } else if (request.action === 'getLastParseResult') {
        // Отправляем последние сохраненные результаты
        chrome.storage.local.get(['lastParseResult', 'lastParseTime'], (result) => {
            sendResponse({
                success: true,
                data: result.lastParseResult,
                timestamp: result.lastParseTime
            });
        });
        return true;
    }
}); 