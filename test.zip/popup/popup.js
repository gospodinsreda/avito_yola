document.addEventListener('DOMContentLoaded', function() {
    const resultsDiv = document.getElementById('results');
    const statusSpan = document.getElementById('status');
    const dataPre = document.getElementById('data');
    const loader = document.querySelector('.loader');
    const dateFromInput = document.getElementById('dateFrom');
    const dateToInput = document.getElementById('dateTo');
    const dateTypeSelect = document.getElementById('dateType');

    // Установка начальных дат (текущий месяц)
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    dateFromInput.value = firstDay.toISOString().split('T')[0];
    dateToInput.value = lastDay.toISOString().split('T')[0];

    function showLoader() {
        loader.style.display = 'block';
        statusSpan.textContent = 'Загрузка...';
        dataPre.innerHTML = '';
    }

    function hideLoader() {
        loader.style.display = 'none';
        statusSpan.textContent = 'Готов к работе';
    }

    // Функция для поиска вкладки с бронированиями
    async function findBookingTab() {
        return new Promise((resolve) => {
            chrome.tabs.query({}, (tabs) => {
                const bookingTab = tabs.find(tab => 
                    tab.url?.includes('admin.booking.com') && 
                    tab.url?.includes('search_reservations.html')
                );
                resolve(bookingTab);
            });
        });
    }

    // Функция для проверки и инъекции скриптов
    async function ensureScriptsInjected(tabId) {
        return new Promise((resolve, reject) => {
            // Пробуем отправить ping
            chrome.tabs.sendMessage(tabId, { action: 'ping' }, response => {
                if (chrome.runtime.lastError) {
                    console.log('Scripts not loaded, injecting...');
                    // Если скрипты не загружены, загружаем их
                    chrome.scripting.executeScript({
                        target: { tabId },
                        files: [
                            'scripts/modules/parser.js',
                            'scripts/modules/navigation.js',
                            'scripts/content.js'
                        ]
                    }).then(() => {
                        console.log('Scripts injected successfully');
                        // Даем небольшую задержку для инициализации
                        setTimeout(resolve, 1000);
                    }).catch(reject);
                } else {
                    console.log('Scripts already loaded');
                    resolve();
                }
            });
        });
    }

    function displayResults(response) {
        if (!response) {
            handleError(new Error('Нет ответа от страницы'));
            return;
        }

        if (!response.success) {
            handleError(new Error(response.error || 'Неизвестная ошибка'));
            return;
        }

        // Если нужна навигация, выполняем её
        if (response.needsNavigation && response.url) {
            findBookingTab().then(async bookingTab => {
                if (!bookingTab) {
                    handleError(new Error('Не найдена вкладка с бронированиями. Пожалуйста, откройте страницу бронирований.'));
                    return;
                }

                try {
                    await ensureScriptsInjected(bookingTab.id);
                    // Сообщаем background скрипту о начале навигации
                    chrome.runtime.sendMessage({ action: 'startNavigation' }, () => {
                        chrome.tabs.update(bookingTab.id, { url: response.url });
                        statusSpan.textContent = 'Переход на страницу с выбранными датами...';
                    });
                } catch (error) {
                    handleError(error);
                }
            });
            return;
        }

        dataPre.innerHTML = JSON.stringify(response.data, null, 2);
        hideLoader();
    }

    function handleError(error) {
        statusSpan.textContent = 'Ошибка!';
        dataPre.innerHTML = `Ошибка: ${error.message}`;
        hideLoader();
    }

    // Слушаем сообщения от background script
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'parseComplete') {
            displayResults({ success: true, data: request.data });
        }
    });

    // При открытии popup проверяем наличие последних результатов
    chrome.runtime.sendMessage({ action: 'getLastParseResult' }, (response) => {
        if (response?.success && response?.data) {
            const timestamp = new Date(response.timestamp);
            const now = new Date();
            // Показываем результаты только если они не старше 5 минут
            if (now - timestamp < 5 * 60 * 1000) {
                displayResults({ success: true, data: response.data });
            }
        }
    });

    // Парсинг бронировани��
    document.getElementById('parseBookings').addEventListener('click', async () => {
        showLoader();
        try {
            const bookingTab = await findBookingTab();
            if (!bookingTab) {
                handleError(new Error('Не найдена вкладка с бронированиями. Пожалуйста, откройте страницу бронирований.'));
                return;
            }

            // Проверяем и инжектим скрипты если нужно
            await ensureScriptsInjected(bookingTab.id);

            const dateParams = {
                dateFrom: dateFromInput.value,
                dateTo: dateToInput.value,
                dateType: dateTypeSelect.value
            };

            chrome.tabs.sendMessage(
                bookingTab.id,
                {
                    action: 'parseBookings',
                    params: dateParams
                },
                function(response) {
                    if (chrome.runtime.lastError) {
                        handleError(new Error(chrome.runtime.lastError.message));
                        return;
                    }
                    displayResults(response);
                }
            );
        } catch (error) {
            handleError(error);
        }
    });

    // Информация об отеле
    document.getElementById('parseHotel').addEventListener('click', async () => {
        showLoader();
        try {
            const bookingTab = await findBookingTab();
            if (!bookingTab) {
                handleError(new Error('Не найдена вкладка с бронированиями. Пожалуйста, откройте страницу бронирований.'));
                return;
            }

            // Проверяем и инжектим скрипты если нужно
            await ensureScriptsInjected(bookingTab.id);

            chrome.tabs.sendMessage(
                bookingTab.id,
                {action: 'parseHotelInfo'},
                function(response) {
                    if (chrome.runtime.lastError) {
                        handleError(new Error(chrome.runtime.lastError.message));
                        return;
                    }
                    displayResults(response);
                }
            );
        } catch (error) {
            handleError(error);
        }
    });

    // Экспорт данных
    document.getElementById('exportData').addEventListener('click', () => {
        const data = dataPre.textContent;
        if (data) {
            const blob = new Blob([data], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'booking-data.json';
            a.click();
            URL.revokeObjectURL(url);
        } else {
            statusSpan.textContent = 'Нет данных для экспорта';
        }
    });
});