class BookingStorage {
    constructor() {
        this.storageKey = 'booking_analyzer_data';
    }

    // Сохранение данных
    async saveData(data, category) {
        try {
            const existingData = await this.getAllData();
            existingData[category] = data;
            
            await chrome.storage.local.set({
                [this.storageKey]: existingData
            });
            
            console.log(`Data saved for category: ${category}`);
            return true;
        } catch (error) {
            console.error('Error saving data:', error);
            return false;
        }
    }

    // Получение данных по категории
    async getData(category) {
        try {
            const result = await chrome.storage.local.get(this.storageKey);
            return result[this.storageKey]?.[category] || null;
        } catch (error) {
            console.error('Error getting data:', error);
            return null;
        }
    }

    // Получение всех данных
    async getAllData() {
        try {
            const result = await chrome.storage.local.get(this.storageKey);
            return result[this.storageKey] || {};
        } catch (error) {
            console.error('Error getting all data:', error);
            return {};
        }
    }

    // Очистка данных
    async clearData(category = null) {
        try {
            if (category) {
                const existingData = await this.getAllData();
                delete existingData[category];
                await chrome.storage.local.set({
                    [this.storageKey]: existingData
                });
            } else {
                await chrome.storage.local.remove(this.storageKey);
            }
            return true;
        } catch (error) {
            console.error('Error clearing data:', error);
            return false;
        }
    }
}

window.BookingStorage = BookingStorage; 